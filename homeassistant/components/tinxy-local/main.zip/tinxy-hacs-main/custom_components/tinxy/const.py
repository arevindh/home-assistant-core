"""Constants for the Tinxy integration."""

DOMAIN = "tinxy"
CONF_API_KEY = "api_key"
COORDINATOR = "coordinator"
TINXY_BACKEND = "https://ha-backend.tinxy.in/"
